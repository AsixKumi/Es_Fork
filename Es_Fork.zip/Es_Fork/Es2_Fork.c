/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    // Il padre crea 3 figli
    for (int i = 0; i < 3; i++) {
        int pid = fork();

        if (pid == 0) {
            // FIGLIO: stampa il PID e termina
            printf("Sono il figlio %d, il mio PID e' %d\n", i + 1, getpid());
            return 0; // il figlio esce qui, non crea altri figli
        }
    }

    // PADRE: aspetta tutti e 3 i figli
    for (int i = 0; i < 3; i++) {
        wait(NULL);
    }

    printf("Tutti i figli hanno terminato. Fine del padre.\n");

    return 0;
}
