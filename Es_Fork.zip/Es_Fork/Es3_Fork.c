/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    // Processo originale = NONNO
    int pid1 = fork();

    if (pid1 == 0) {
        // Qui siamo nel PADRE (figlio del nonno)
        int pid2 = fork();

        if (pid2 == 0) {
            // Qui siamo nel NIPOTE
            printf("Sono il nipote (PID %d). Chiudo.\n", getpid());
        } else {
            // PADRE: aspetta il nipote, poi saluta
            wait(NULL);
            printf("Sono il padre (PID %d). Chiudo.\n", getpid());
        }
    } else {
        // NONNO: aspetta il padre, poi saluta
        wait(NULL);
        printf("Sono il nonno (PID %d). Chiudo.\n", getpid());
    }

    return 0;
}