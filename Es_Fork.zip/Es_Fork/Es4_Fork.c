/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int pid = fork();

    if (pid == 0) {
        // FIGLIO: chiede un numero e controlla di che tipo e'
        int n;
        printf("Inserisci un numero intero: ");
        scanf("%d", &n);

        // Controllo se e' primo
        int primo = 1;
        if (n < 2) {
            primo = 0; // 0, 1 e i negativi non sono primi
        }
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                primo = 0;
            }
        }

        if (primo == 1) {
            exit(1);        // primo
        } else if (n % 2 == 0) {
            exit(2);        // pari (non primo)
        } else {
            exit(3);        // dispari (non primo)
        }
    } else {
        // PADRE: aspetta il figlio e legge il codice di uscita
        int status;
        wait(&status);
        int codice = WEXITSTATUS(status);

        if (codice == 1) {
            printf("Il numero e' primo.\n");
        } else if (codice == 2) {
            printf("Il numero e' pari (non primo).\n");
        } else if (codice == 3) {
            printf("Il numero e' dispari (non primo).\n");
        }
    }

    return 0;
}