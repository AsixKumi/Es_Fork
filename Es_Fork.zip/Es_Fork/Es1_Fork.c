/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    int pid = fork();

    if (pid == 0) {
        // FIGLIO: stampa da 1 a 5
        for (int i = 1; i <= 5; i++) {
            printf("Figlio: %d\n", i);
        }
    } else {
        // PADRE: aspetta il figlio, poi stampa da 6 a 10
        wait(NULL);
        for (int i = 6; i <= 10; i++) {
            printf("Padre: %d\n", i);
        }
    }

    return 0;
}
